from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.db import transaction
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.http import require_POST

from .forms import BookingForm, CustomerLoginForm, CustomerRegistrationForm, StaffBookingUpdateForm
from .models import Booking, CustomerProfile, ServiceCategory, ServiceItem


def home(request):
    categories = ServiceCategory.objects.prefetch_related("services").all()
    featured_services = ServiceItem.objects.filter(is_active=True).select_related("category")[:6]
    return render(request, "services/index.html", {"categories": categories, "featured_services": featured_services})


def service_list(request):
    services = ServiceItem.objects.filter(is_active=True).select_related("category")
    categories = ServiceCategory.objects.all()
    selected_category = request.GET.get("category", "")
    search_query = request.GET.get("q", "").strip()
    if selected_category:
        services = services.filter(category__slug=selected_category)
    if search_query:
        services = services.filter(title__icontains=search_query) | services.filter(description__icontains=search_query)
        services = services.distinct()
    return render(request, "services/service_list.html", {
        "services": services, "categories": categories,
        "selected_category": selected_category, "search_query": search_query,
    })


def service_detail(request, pk):
    service = get_object_or_404(ServiceItem.objects.select_related("category"), pk=pk, is_active=True)
    related_services = ServiceItem.objects.filter(category=service.category, is_active=True).exclude(pk=service.pk)[:3]
    return render(request, "services/service_detail.html", {"service": service, "related_services": related_services})


def register(request):
    if request.user.is_authenticated:
        return redirect("dashboard")
    form = CustomerRegistrationForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, "Your account has been created. You can book a service now.")
        return redirect("dashboard")
    return render(request, "services/register.html", {"form": form})


def user_login(request):
    if request.user.is_authenticated:
        return redirect("dashboard")
    form = CustomerLoginForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = authenticate(request, username=form.cleaned_data["username"], password=form.cleaned_data["password"])
        if user is not None:
            login(request, user)
            next_url = request.GET.get("next") or request.POST.get("next")
            if next_url and url_has_allowed_host_and_scheme(next_url, allowed_hosts={request.get_host()}, require_https=request.is_secure()):
                return redirect(next_url)
            return redirect("dashboard")
        messages.error(request, "Username or password is incorrect.")
    return render(request, "services/login.html", {"form": form, "next": request.GET.get("next", "")})


@require_POST
def user_logout(request):
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect("home")


@login_required
def book_service(request, service_id):
    service = get_object_or_404(ServiceItem, pk=service_id, is_active=True)
    profile = CustomerProfile.objects.filter(user=request.user).first()
    initial = {}
    if profile:
        initial = {"contact_phone": profile.phone_number, "delivery_address": profile.address}
    form = BookingForm(request.POST or None, initial=initial if request.method == "GET" else None)
    if request.method == "POST" and form.is_valid():
        booking = form.save(commit=False)
        booking.customer = request.user
        booking.service_item = service
        booking.total_price = service.price
        booking.save()
        if profile:
            profile.phone_number = booking.contact_phone
            profile.address = booking.delivery_address
            profile.save(update_fields=["phone_number", "address"])
        messages.success(request, f"Booking #{booking.pk} placed successfully. We’ll confirm it shortly.")
        return redirect("dashboard")
    return render(request, "services/book_service.html", {"form": form, "service": service})


@login_required
def dashboard(request):
    bookings = Booking.objects.filter(customer=request.user).select_related(
        "service_item", "service_item__category", "assigned_technician"
    )
    return render(request, "services/dashboard.html", {"bookings": bookings})


@login_required
def booking_status_api(request):
    """Small JSON endpoint used by the dashboard to refresh the customer's statuses."""
    bookings = Booking.objects.filter(customer=request.user).values("id", "status")
    return JsonResponse({"bookings": list(bookings)})


def is_staff_user(user):
    return user.is_authenticated and user.is_staff


@user_passes_test(is_staff_user)
def admin_dashboard(request):
    bookings = Booking.objects.select_related(
        "customer", "service_item", "service_item__category", "assigned_technician"
    ).all()
    status_filter = request.GET.get("status", "")
    if status_filter in Booking.Status.values:
        bookings = bookings.filter(status=status_filter)
    booking_rows = [
        {"booking": booking, "form": StaffBookingUpdateForm(instance=booking, booking=booking)}
        for booking in bookings
    ]
    return render(request, "services/admin_dashboard.html", {
        "booking_rows": booking_rows,
        "status_choices": Booking.Status.choices,
        "selected_status": status_filter,
    })


@user_passes_test(is_staff_user)
@require_POST
def update_booking_status(request, booking_id):
    booking = get_object_or_404(Booking.objects.select_related("service_item__category"), pk=booking_id)
    old_technician = booking.assigned_technician
    form = StaffBookingUpdateForm(request.POST, instance=booking, booking=booking)
    if form.is_valid():
        with transaction.atomic():
            updated_booking = form.save()
            new_technician = updated_booking.assigned_technician
            if old_technician and old_technician.pk != getattr(new_technician, "pk", None):
                old_technician.is_available = True
                old_technician.save(update_fields=["is_available"])
            if new_technician:
                new_technician.is_available = updated_booking.status not in (
                    Booking.Status.ASSIGNED, Booking.Status.IN_PROGRESS
                )
                new_technician.save(update_fields=["is_available"])
        messages.success(request, f"Booking #{booking.pk} has been updated.")
    else:
        messages.error(request, f"Could not update booking #{booking.pk}. Check the selected technician and status.")
    return redirect("admin_dashboard")
