from django.conf import settings
from django.core.validators import MinValueValidator, RegexValidator
from django.db import models
from django.utils.text import slugify

phone_validator = RegexValidator(
    regex=r"^\+?[0-9]{10,15}$",
    message="Enter a valid phone number (10–15 digits, with optional +, spaces or hyphens).",
)
pincode_validator = RegexValidator(
    regex=r"^[1-9][0-9]{5}$",
    message="Enter a valid 6-digit Indian PIN code.",
)


class CustomerProfile(models.Model):
    """Additional customer information attached to Django's built-in User."""
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="customer_profile")
    phone_number = models.CharField(max_length=16, validators=[phone_validator])
    address = models.TextField(blank=True)
    pincode = models.CharField(max_length=6, blank=True, validators=[pincode_validator])

    def __str__(self):
        return f"{self.user.get_full_name() or self.user.username} — profile"


class ServiceCategory(models.Model):
    name = models.CharField(max_length=80, unique=True)
    slug = models.SlugField(max_length=100, unique=True, blank=True)
    description = models.TextField(blank=True)
    icon = models.CharField(max_length=80, default="bi-tools", help_text="Bootstrap Icons class, e.g. bi-lightning-charge-fill")

    class Meta:
        ordering = ["name"]
        verbose_name_plural = "service categories"

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name


class ServiceItem(models.Model):
    title = models.CharField(max_length=140)
    category = models.ForeignKey(ServiceCategory, on_delete=models.PROTECT, related_name="services")
    price = models.DecimalField(max_digits=9, decimal_places=2, validators=[MinValueValidator(0)])
    duration = models.CharField(max_length=60, help_text="Example: 45–60 mins")
    description = models.TextField()
    image = models.ImageField(upload_to="service_items/", blank=True, null=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["category__name", "title"]

    def __str__(self):
        return self.title


class Technician(models.Model):
    class Specialization(models.TextChoices):
        ELECTRICAL = "Electrical", "Electrical"
        PLUMBING = "Plumbing", "Plumbing"

    name = models.CharField(max_length=120)
    specialization = models.CharField(max_length=20, choices=Specialization.choices)
    phone = models.CharField(max_length=16, validators=[phone_validator])
    is_available = models.BooleanField(default=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return f"{self.name} ({self.specialization})"


class Booking(models.Model):
    class Status(models.TextChoices):
        PENDING = "Pending", "Pending"
        ASSIGNED = "Assigned", "Assigned"
        IN_PROGRESS = "In Progress", "In Progress"
        COMPLETED = "Completed", "Completed"
        CANCELLED = "Cancelled", "Cancelled"

    TIME_SLOTS = [
        ("08:00 AM - 10:00 AM", "08:00 AM - 10:00 AM"),
        ("10:00 AM - 12:00 PM", "10:00 AM - 12:00 PM"),
        ("12:00 PM - 02:00 PM", "12:00 PM - 02:00 PM"),
        ("02:00 PM - 04:00 PM", "02:00 PM - 04:00 PM"),
        ("04:00 PM - 06:00 PM", "04:00 PM - 06:00 PM"),
        ("06:00 PM - 08:00 PM", "06:00 PM - 08:00 PM"),
    ]

    customer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="service_bookings")
    service_item = models.ForeignKey(ServiceItem, on_delete=models.PROTECT, related_name="bookings")
    assigned_technician = models.ForeignKey(
        Technician, on_delete=models.SET_NULL, null=True, blank=True, related_name="bookings"
    )
    booking_date = models.DateField()
    time_slot = models.CharField(max_length=40, choices=TIME_SLOTS)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    total_price = models.DecimalField(max_digits=9, decimal_places=2, validators=[MinValueValidator(0)])
    delivery_address = models.TextField()
    contact_phone = models.CharField(max_length=16, validators=[phone_validator])
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"Booking #{self.pk} — {self.service_item.title}"
