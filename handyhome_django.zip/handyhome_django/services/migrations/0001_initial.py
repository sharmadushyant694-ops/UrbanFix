# Initial schema for HandyHome.
import django.core.validators
import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True

    dependencies = [migrations.swappable_dependency(settings.AUTH_USER_MODEL)]

    operations = [
        migrations.CreateModel(
            name="ServiceCategory",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=80, unique=True)),
                ("slug", models.SlugField(blank=True, max_length=100, unique=True)),
                ("description", models.TextField(blank=True)),
                ("icon", models.CharField(default="bi-tools", help_text="Bootstrap Icons class, e.g. bi-lightning-charge-fill", max_length=80)),
            ],
            options={"ordering": ["name"], "verbose_name_plural": "service categories"},
        ),
        migrations.CreateModel(
            name="Technician",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=120)),
                ("specialization", models.CharField(choices=[("Electrical", "Electrical"), ("Plumbing", "Plumbing")], max_length=20)),
                ("phone", models.CharField(max_length=16, validators=[django.core.validators.RegexValidator(message="Enter a valid phone number (10–15 digits, with optional +, spaces or hyphens).", regex="^\\+?[0-9]{10,15}$")])),
                ("is_available", models.BooleanField(default=True)),
            ],
            options={"ordering": ["name"]},
        ),
        migrations.CreateModel(
            name="CustomerProfile",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("phone_number", models.CharField(max_length=16, validators=[django.core.validators.RegexValidator(message="Enter a valid phone number (10–15 digits, with optional +, spaces or hyphens).", regex="^\\+?[0-9]{10,15}$")])),
                ("address", models.TextField(blank=True)),
                ("pincode", models.CharField(blank=True, max_length=6, validators=[django.core.validators.RegexValidator(message="Enter a valid 6-digit Indian PIN code.", regex="^[1-9][0-9]{5}$")])),
                ("user", models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name="customer_profile", to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name="ServiceItem",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("title", models.CharField(max_length=140)),
                ("price", models.DecimalField(decimal_places=2, max_digits=9, validators=[django.core.validators.MinValueValidator(0)])),
                ("duration", models.CharField(help_text="Example: 45–60 mins", max_length=60)),
                ("description", models.TextField()),
                ("image", models.ImageField(blank=True, null=True, upload_to="service_items/")),
                ("is_active", models.BooleanField(default=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("category", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="services", to="services.servicecategory")),
            ],
            options={"ordering": ["category__name", "title"]},
        ),
        migrations.CreateModel(
            name="Booking",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("booking_date", models.DateField()),
                ("time_slot", models.CharField(choices=[("08:00 AM - 10:00 AM", "08:00 AM - 10:00 AM"), ("10:00 AM - 12:00 PM", "10:00 AM - 12:00 PM"), ("12:00 PM - 02:00 PM", "12:00 PM - 02:00 PM"), ("02:00 PM - 04:00 PM", "02:00 PM - 04:00 PM"), ("04:00 PM - 06:00 PM", "04:00 PM - 06:00 PM"), ("06:00 PM - 08:00 PM", "06:00 PM - 08:00 PM")], max_length=40)),
                ("status", models.CharField(choices=[("Pending", "Pending"), ("Assigned", "Assigned"), ("In Progress", "In Progress"), ("Completed", "Completed"), ("Cancelled", "Cancelled")], default="Pending", max_length=20)),
                ("total_price", models.DecimalField(decimal_places=2, max_digits=9, validators=[django.core.validators.MinValueValidator(0)])),
                ("delivery_address", models.TextField()),
                ("contact_phone", models.CharField(max_length=16, validators=[django.core.validators.RegexValidator(message="Enter a valid phone number (10–15 digits, with optional +, spaces or hyphens).", regex="^\\+?[0-9]{10,15}$")])),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("assigned_technician", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="bookings", to="services.technician")),
                ("customer", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="service_bookings", to=settings.AUTH_USER_MODEL)),
                ("service_item", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="bookings", to="services.serviceitem")),
            ],
            options={"ordering": ["-created_at"]},
        ),
    ]
