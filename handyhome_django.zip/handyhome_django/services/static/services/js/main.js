(function () {
  "use strict";

  // Refresh booking badges without reloading the full customer dashboard.
  const dashboard = document.getElementById("booking-dashboard");
  if (dashboard) {
    const endpoint = dashboard.dataset.statusUrl;
    const statusClasses = {
      "Pending": "status-pending",
      "Assigned": "status-assigned",
      "In Progress": "status-progress",
      "Completed": "status-completed",
      "Cancelled": "status-cancelled"
    };

    async function refreshStatuses() {
      try {
        const response = await fetch(endpoint, {
          headers: { "X-Requested-With": "XMLHttpRequest" },
          credentials: "same-origin"
        });
        if (!response.ok) return;
        const payload = await response.json();
        payload.bookings.forEach((booking) => {
          const badge = document.getElementById(`status-${booking.id}`);
          if (!badge) return;
          badge.textContent = booking.status;
          badge.className = `status-badge ${statusClasses[booking.status] || "status-pending"}`;
        });
      } catch (error) {
        // A temporary network failure should not interrupt the dashboard.
        console.debug("Booking status refresh skipped.", error);
      }
    }

    window.setInterval(refreshStatuses, 25000);
  }

  // Submit the category filter when changed for a quicker catalogue workflow.
  const categoryFilter = document.getElementById("categoryFilter");
  if (categoryFilter) {
    categoryFilter.addEventListener("change", () => categoryFilter.form.requestSubmit());
  }
})();
