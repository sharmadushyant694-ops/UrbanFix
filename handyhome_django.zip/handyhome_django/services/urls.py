from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("services/", views.service_list, name="service_list"),
    path("services/<int:pk>/", views.service_detail, name="service_detail"),
    path("services/<int:service_id>/book/", views.book_service, name="book_service"),
    path("register/", views.register, name="register"),
    path("login/", views.user_login, name="login"),
    path("logout/", views.user_logout, name="logout"),
    path("dashboard/", views.dashboard, name="dashboard"),
    path("dashboard/status.json", views.booking_status_api, name="booking_status_api"),
    path("staff/", views.admin_dashboard, name="admin_dashboard"),
    path("staff/bookings/<int:booking_id>/update/", views.update_booking_status, name="update_booking_status"),
]
