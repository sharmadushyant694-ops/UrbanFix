import re
from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm
from django.db.models import Q
from django.utils import timezone
from .models import Booking, CustomerProfile, Technician

User = get_user_model()


class CustomerRegistrationForm(UserCreationForm):
    password1 = forms.CharField(
        label="Password",
        strip=False,
        widget=forms.PasswordInput(attrs={"class": "form-control", "autocomplete": "new-password"}),
    )
    password2 = forms.CharField(
        label="Confirm password",
        strip=False,
        widget=forms.PasswordInput(attrs={"class": "form-control", "autocomplete": "new-password"}),
    )
    first_name = forms.CharField(max_length=150, required=True, widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "First name"}))
    last_name = forms.CharField(max_length=150, required=False, widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "Last name"}))
    email = forms.EmailField(required=True, widget=forms.EmailInput(attrs={"class": "form-control", "placeholder": "you@example.com"}))
    phone_number = forms.CharField(max_length=16, widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "10-digit mobile number", "autocomplete": "tel"}))
    address = forms.CharField(required=False, widget=forms.Textarea(attrs={"class": "form-control", "rows": 2, "placeholder": "House / street / locality"}))
    pincode = forms.CharField(max_length=6, required=False, widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "6-digit PIN code", "inputmode": "numeric"}))

    class Meta:
        model = User
        fields = ("username", "first_name", "last_name", "email", "phone_number", "address", "pincode", "password1", "password2")
        widgets = {
            "username": forms.TextInput(attrs={"class": "form-control", "placeholder": "Choose a username", "autocomplete": "username"}),
            "password1": forms.PasswordInput(attrs={"class": "form-control", "autocomplete": "new-password"}),
            "password2": forms.PasswordInput(attrs={"class": "form-control", "autocomplete": "new-password"}),
        }

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("An account with this email already exists.")
        return email

    def clean_phone_number(self):
        phone = self.cleaned_data["phone_number"].strip()
        normalized = re.sub(r"[\s-]", "", phone)
        if not re.fullmatch(r"\+?[0-9]{10,15}", normalized):
            raise forms.ValidationError("Enter a valid phone number with 10–15 digits.")
        return normalized

    def clean_pincode(self):
        pincode = self.cleaned_data.get("pincode", "").strip()
        if pincode and not re.fullmatch(r"[1-9][0-9]{5}", pincode):
            raise forms.ValidationError("Enter a valid 6-digit Indian PIN code.")
        return pincode

    def save(self, commit=True):
        user = super().save(commit=False)
        user.first_name = self.cleaned_data["first_name"]
        user.last_name = self.cleaned_data["last_name"]
        user.email = self.cleaned_data["email"]
        if commit:
            user.save()
            CustomerProfile.objects.update_or_create(
                user=user,
                defaults={
                    "phone_number": self.cleaned_data["phone_number"],
                    "address": self.cleaned_data["address"],
                    "pincode": self.cleaned_data["pincode"],
                },
            )
        return user


class CustomerLoginForm(forms.Form):
    username = forms.CharField(widget=forms.TextInput(attrs={"class": "form-control", "autocomplete": "username"}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={"class": "form-control", "autocomplete": "current-password"}))


class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ("booking_date", "time_slot", "delivery_address", "contact_phone")
        widgets = {
            "booking_date": forms.DateInput(attrs={"class": "form-control", "type": "date"}, format="%Y-%m-%d"),
            "time_slot": forms.Select(attrs={"class": "form-select"}),
            "delivery_address": forms.Textarea(attrs={"class": "form-control", "rows": 3, "placeholder": "Complete address with landmark"}),
            "contact_phone": forms.TextInput(attrs={"class": "form-control", "placeholder": "10-digit mobile number", "inputmode": "tel"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["booking_date"].input_formats = ["%Y-%m-%d"]
        self.fields["booking_date"].widget.attrs["min"] = timezone.localdate().isoformat()

    def clean_booking_date(self):
        booking_date = self.cleaned_data["booking_date"]
        if booking_date < timezone.localdate():
            raise forms.ValidationError("Please choose today or a future date.")
        return booking_date

    def clean_contact_phone(self):
        phone = self.cleaned_data["contact_phone"].strip()
        normalized = re.sub(r"[\s-]", "", phone)
        if not re.fullmatch(r"\+?[0-9]{10,15}", normalized):
            raise forms.ValidationError("Enter a valid contact phone number with 10–15 digits.")
        return normalized


class StaffBookingUpdateForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ("assigned_technician", "status")
        widgets = {
            "assigned_technician": forms.Select(attrs={"class": "form-select form-select-sm"}),
            "status": forms.Select(attrs={"class": "form-select form-select-sm"}),
        }

    def __init__(self, *args, booking=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.booking = booking or self.instance
        if self.booking and self.booking.pk:
            specialization = self.booking.service_item.category.name
            active_statuses = [Booking.Status.ASSIGNED, Booking.Status.IN_PROGRESS]
            available = Technician.objects.filter(
                specialization__iexact=specialization, is_available=True
            ).exclude(
                bookings__status__in=active_statuses
            ).distinct()
            current_id = self.booking.assigned_technician_id
            if current_id:
                available = Technician.objects.filter(Q(pk__in=available.values("pk")) | Q(pk=current_id)).distinct()
            self.fields["assigned_technician"].queryset = available
        else:
            self.fields["assigned_technician"].queryset = Technician.objects.none()
        self.fields["assigned_technician"].required = False
        if self.booking and self.booking.pk:
            self.fields["assigned_technician"].widget.attrs["id"] = f"tech-{self.booking.pk}"
        self.fields["status"].widget.attrs["aria-label"] = "Booking status"

    def clean(self):
        cleaned = super().clean()
        status = cleaned.get("status")
        technician = cleaned.get("assigned_technician")
        if status in (Booking.Status.ASSIGNED, Booking.Status.IN_PROGRESS) and not technician:
            self.add_error("assigned_technician", "Assign a technician before setting this status.")
        if technician and self.booking and self.booking.pk:
            if technician.specialization.lower() != self.booking.service_item.category.name.lower():
                self.add_error("assigned_technician", "Choose a technician with the matching specialization.")
        return cleaned
