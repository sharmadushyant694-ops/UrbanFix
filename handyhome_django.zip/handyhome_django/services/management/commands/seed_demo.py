from django.core.management.base import BaseCommand
from services.models import ServiceCategory, ServiceItem, Technician


class Command(BaseCommand):
    help = "Create sample electrical/plumbing services and technicians for local testing."

    def handle(self, *args, **options):
        electrical, _ = ServiceCategory.objects.update_or_create(
            slug="electrical",
            defaults={"name": "Electrical", "description": "Safe, reliable electrical repairs and installations.", "icon": "bi-lightning-charge-fill"},
        )
        plumbing, _ = ServiceCategory.objects.update_or_create(
            slug="plumbing",
            defaults={"name": "Plumbing", "description": "Quick solutions for leaks, taps, pipes and fittings.", "icon": "bi-droplet-fill"},
        )
        samples = [
            ("Fan installation", electrical, "499.00", "45–60 mins", "Professional ceiling or wall fan installation with secure fitting and a safety check."),
            ("Switch & socket repair", electrical, "249.00", "30–45 mins", "Inspection and repair of faulty switches, sockets and loose connections."),
            ("MCB / fuse issue", electrical, "399.00", "45–60 mins", "Troubleshooting for tripping MCBs, fuse problems and common power interruptions."),
            ("Tap repair & replacement", plumbing, "199.00", "30–45 mins", "Fix dripping taps or replace worn-out tap fittings."),
            ("Pipe leakage repair", plumbing, "349.00", "45–90 mins", "Identify and repair common water pipe leaks and joint issues."),
            ("Washbasin blockage", plumbing, "299.00", "30–60 mins", "Clear common washbasin drainage blockages and check water flow."),
        ]
        for title, category, price, duration, description in samples:
            ServiceItem.objects.update_or_create(
                title=title, defaults={"category": category, "price": price, "duration": duration, "description": description, "is_active": True}
            )
        Technician.objects.get_or_create(name="Amit Kumar", defaults={"specialization": "Electrical", "phone": "9876543210", "is_available": True})
        Technician.objects.get_or_create(name="Ravi Sharma", defaults={"specialization": "Plumbing", "phone": "9876501234", "is_available": True})
        self.stdout.write(self.style.SUCCESS("Demo categories, services and technicians are ready."))
