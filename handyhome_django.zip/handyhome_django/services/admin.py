from django.contrib import admin
from .models import Booking, CustomerProfile, ServiceCategory, ServiceItem, Technician


@admin.register(ServiceCategory)
class ServiceCategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "icon")
    prepopulated_fields = {"slug": ("name",)}
    search_fields = ("name",)


@admin.register(ServiceItem)
class ServiceItemAdmin(admin.ModelAdmin):
    list_display = ("title", "category", "price", "duration", "is_active")
    list_filter = ("category", "is_active")
    search_fields = ("title", "description")


@admin.register(Technician)
class TechnicianAdmin(admin.ModelAdmin):
    list_display = ("name", "specialization", "phone", "is_available")
    list_filter = ("specialization", "is_available")
    search_fields = ("name", "phone")


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ("id", "customer", "service_item", "booking_date", "time_slot", "status", "assigned_technician")
    list_filter = ("status", "booking_date", "service_item__category")
    search_fields = ("customer__username", "customer__email", "contact_phone")
    list_select_related = ("customer", "service_item", "assigned_technician")


@admin.register(CustomerProfile)
class CustomerProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "phone_number", "pincode")
    search_fields = ("user__username", "phone_number", "pincode")
