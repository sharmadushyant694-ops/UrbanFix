# HandyHome — Django Home Service Booking

A local-ready Django starter project for booking electrical and plumbing services. It includes customer registration/login, a service catalogue, bookings, a customer dashboard with status polling, and a staff-only provider panel for technician assignment and booking status updates.

## 1. Requirements

- Python 3.10+
- pip
- A terminal / command prompt

SQLite is configured by default, so no separate database server is required. PostgreSQL is also supported by setting the `DB_ENGINE=postgresql` and `DB_*` environment variables described below.

## 2. Run locally

Open a terminal in the `handyhome_django` folder and run:

### Windows (PowerShell / CMD)

```powershell
py -m venv venv
venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python manage.py migrate
python manage.py seed_demo
python manage.py createsuperuser
python manage.py runserver
```

### macOS / Linux

```bash
python3 -m venv venv
source venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python manage.py migrate
python manage.py seed_demo
python manage.py createsuperuser
python manage.py runserver
```

Open **http://127.0.0.1:8000/**.

## 3. Main URLs

| URL | Purpose |
|---|---|
| `/` | Home page |
| `/services/` | Search and filter services |
| `/register/` | Customer registration |
| `/login/` | Customer / staff login |
| `/dashboard/` | Customer bookings |
| `/staff/` | Staff-only booking and technician panel |
| `/django-admin/` | Django admin |

### Optional PostgreSQL configuration

Install the PostgreSQL driver with `pip install "psycopg[binary]"`, then set these environment variables before running migrations:

```text
DB_ENGINE=postgresql
DB_NAME=handyhome
DB_USER=postgres
DB_PASSWORD=your-password
DB_HOST=127.0.0.1
DB_PORT=5432
```

When `DB_ENGINE` is omitted or set to `sqlite`, the project uses the local SQLite database.

## 4. First-time use

1. Run `python manage.py seed_demo` to add the two categories, six sample services and two sample technicians.
2. Create a normal customer account from `/register/` and place a booking.
3. Use the superuser created by `createsuperuser` to sign in. The superuser is a staff user and can open `/staff/` to assign technicians and update booking statuses.
4. Add/edit categories, service items and technicians at `/django-admin/`.

The demo catalogue uses sample prices and descriptions. Replace them with your actual business information.

## 5. Project structure

```text
handyhome_django/
├── manage.py
├── requirements.txt
├── README.md
├── config/
│   ├── settings.py
│   ├── urls.py
│   ├── asgi.py
│   └── wsgi.py
└── services/
    ├── admin.py
    ├── apps.py
    ├── forms.py
    ├── models.py
    ├── urls.py
    ├── views.py
    ├── migrations/0001_initial.py
    ├── management/commands/seed_demo.py
    ├── templates/services/
    └── static/services/{css,js}/
```

## 6. Implementation notes

- The customer profile is a `OneToOneField` extension of Django's built-in user model.
- Bookings store a snapshot of the service price in `total_price`, so a later catalogue price change does not rewrite an existing booking.
- Booking creation and staff status updates use POST forms with Django CSRF tokens.
- The provider panel is restricted to authenticated users with `is_staff=True`.
- Technician options are filtered to the matching specialization and available technicians. A technician cannot be assigned to another active (`Assigned` / `In Progress`) booking through this form.
- Customer status badges refresh from a small authenticated JSON endpoint every 25 seconds while the dashboard is open.
- The booking form stores a contact phone and address with the booking; the phone/address are also copied to the profile where a profile exists.

## 7. Before production deployment

This is a development starter, not a finished production deployment. Before going live:

- Set a strong `DJANGO_SECRET_KEY`, `DJANGO_DEBUG=0`, and an explicit `DJANGO_ALLOWED_HOSTS` environment variable in your operating system or hosting provider. The included `.env.example` is a reference template; this project does not automatically load `.env` files.
- Configure PostgreSQL if required, HTTPS, secure cookies, static/media storage and backups.
- Add real payment handling only through a trusted payment gateway; never store card details yourself.
- Add booking conflict/availability rules, cancellation policy, notifications (SMS/email/WhatsApp), audit logs and tests for your business rules.
- Replace sample testimonials and sample service catalogue content with genuine information.
- Review pricing, taxes, service coverage and local consumer/legal requirements.

Bootstrap 5 and Bootstrap Icons are loaded from their public CDNs, so those assets require an internet connection in the browser.
